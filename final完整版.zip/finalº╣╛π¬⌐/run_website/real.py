# -*- coding: utf-8 -*-
"""
Created on Thu Jul  9 03:26:44 2020

@author: user
"""
from flask import Flask
from flask import request
from flask import render_template
from flask import redirect
import mysql.connector
import csv
from mysql.connector import Error

app = Flask(__name__)
app.debug = True

html_response =  """
<html>
    <head>
        <meta charset="utf-8">
        <title>美國地震資訊</title>
    </head>
    <body>
    <h4> fail </h4>
    </body>
</html>
"""

@app.route("/")
def hello():
    return render_template('db.html')

@app.route("/post_mag", methods=['GET','POST'])
def ok():
    minv = '0'
    maxv = '0'
    locationv = '0'
    start_year = '0'
    start_month = '0'
    start_day = '0'
    start_date = '0'
    end_year = '0'
    end_month = '0'
    end_day = '0'
    end_date = '0'
    if request.method == 'POST':
        minv = request.values['mini']
        maxv = request.values['maxi']
        locationv = request.values['location']
        start_year = request.values['start_year']
        start_month = request.values['start_month']
        start_day = request.values['start_day']
        start_date = start_year + start_month + start_day
        end_year = request.values['end_year']
        end_month = request.values['end_month']
        end_day = request.values['end_day']
        end_date = end_year + end_month + end_day

        try:
            db = mysql.connector.connect(
                host = "127.0.0.1",
                user = "root",
                password = "databasefinal",
                )
        except Exception as ex:
            print(ex)
        cursor = db.cursor()
        cursor.execute("drop database if exists dbFinal")
        cursor.execute("CREATE DATABASE dbFinal")
        cursor.execute("USE dbFinal")

        cursor.execute("drop table if exists earthquake")
        cursor.execute("drop table if exists volcano")
        cursor.execute("drop table if exists stat")

        create_table_earthquake = """
        create table earthquake(
            date int default 0 not null,
            latitude float default 0 not null,
            longitude float default 0 not null,
            depth float default 0 not null,
            magnitude float default 0 not null,
            earthquake_id varchar(18) not null,
            primary key(earthquake_id)
        )
        """
        create_table_volcano = """
        create table volcano(
            volcano_id varchar(6) not null,
            latitude float default 0 not null,
            longitude float default 0 not null,
            elevation int default 0 not null,
            primary key(volcano_id)
        )
        """

        create_table_stat = """
        create table stat(
            state varchar(14) not null,
            leastlongitude float default 0 not null,
            mostlongitude float default 0 not null,
            leastlatitude float default 0 not null,
            mostlatitude float default 0 not null,
            area int default 0 not null,
            primary key(state)
        )
        """
        cursor.execute(create_table_earthquake)
        cursor.execute(create_table_volcano)
        cursor.execute(create_table_stat)

        try:
            with open('earthquake.csv', newline = '') as earthquakefile:
                data_earthquake = csv.reader(earthquakefile)
                for row in data_earthquake:
                    cursor.execute("insert into earthquake values(%s, %s, %s, %s, %s, %s)",row)
        except Exception as ex:
            print(ex)

        try:
            with open('volca.csv', newline = '') as volcanofile:
                data_volcano = csv.reader(volcanofile)
                for row in data_volcano:
                    cursor.execute("insert into volcano values(%s, %s, %s, %s)",row)
        except Exception as ex:
            print(ex)

        try:
            with open('stat.csv', newline = '') as statefile:
                data_state = csv.reader(statefile)
                for row in data_state:
                    cursor.execute("insert into stat values(%s, %s, %s, %s, %s, %s)",row)
        except Exception as ex:
            print(ex)


        SQL1 = """
            SELECT  tempstat.state  ,tempe.date , tempe.latitude , tempe.longitude ,tempe.magnitude
            FROM
                    (SELECT *
                FROM earthquake e
                WHERE e.date BETWEEN %s AND %s
                ) as tempe
                ,
                    ( SELECT *
                    FROM stat s
                    WHERE   s.state LIKE %s
                    ) as tempstat

            WHERE   (tempe.latitude BETWEEN tempstat.leastlatitude AND tempstat.mostlatitude) AND
                    ( tempe.longitude BETWEEN  tempstat.leastlongitude AND tempstat.mostlongitude )
            GROUP BY  tempe.magnitude,tempstat.state ,  tempstat.state  , tempe.date , tempe.latitude , tempe.longitude
            HAVING  tempe.magnitude BETWEEN %s AND %s
            ORDER BY tempe.magnitude desc
            """

        cond1 = [start_date , end_date , locationv , minv , maxv]
        cursor.execute(SQL1,cond1)
        #cursor.execute(SQL1)
        result1 =cursor.fetchall()

        SQL2 = """
        select  outstat.state, num_of_vol.number_of_volcano ,count(tempearth.date) as number_of_earthquake
        , (count(tempearth.date)/outstat.area) *1000 as 'density(num/km^2*1000)'
        ,SUM(tempearth.magnitude) / count(tempearth.date) as 'avg_magnitude'
        FROM
        (
        SELECT count(vol.volcano_id) as number_of_volcano
        FROM
            (select *
            from   stat s
            where  s.state LIKE %s) as tmpstat , volcano vol
        WHERE (vol.latitude BETWEEN tmpstat.leastlatitude AND tmpstat.mostlatitude) AND
            ( vol.longitude BETWEEN  tmpstat.leastlongitude AND tmpstat.mostlongitude )
        ) as num_of_vol ,
        (select *
        from   stat s
        where  s.state LIKE %s) as outstat ,
        (SELECT *
        FROM earthquake e
        WHERE( e.date BETWEEN %s AND %s ) AND e.magnitude BETWEEN %s AND %s
        ) as tempearth
        WHERE (tempearth.latitude BETWEEN outstat.leastlatitude AND outstat.mostlatitude) AND
            ( tempearth.longitude BETWEEN  outstat.leastlongitude AND outstat.mostlongitude )
        GROUP BY outstat.state , num_of_vol.number_of_volcano
        """

        cond2 = [locationv,locationv,start_date,end_date,minv,maxv]
        cursor.execute(SQL2,cond2)
        result2 =cursor.fetchall()

        db.close()
        tablewrite = """<html>
                        <head>
                            <meta charset="utf-8">
                            <title>資料庫</title>
                        </head>
                        <body>
                            <p> <!-- 標題 -->
                                <h1><b>Database Final Project</b> <i>- Horrible Earthquake </i><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1c/USGS_logo_green.svg/1920px-USGS_logo_green.svg.png" alt="圖片無法顯示" title="USGS美國地質調查局"width="100px"height="45px"align="top"></h1>
                            </p>
                            <h4>Team members：黃彥慈、陳睦夫、葉眉湘</h4><hr>
                        <table border = '1'> <tr> <td> state </td> <td> date happened </td> <td>
                        latitude happened </td> <td> longitude happened </td> <td> avg_magnitude </td> </tr>"""
        for i in range (len(result1)):
            tablewrite += "<tr>"
            for j in range (len(result1[0])):
                tablewrite += "<td>"
                tablewrite += str(result1[i][j])
                tablewrite += "</td>"
            tablewrite += "</tr>"
        tablewrite += "<p>"
        tablewrite += """<table border = '1'> <tr> <td> state </td> <td> number of volcano </td> <td>
                        number of earthquake </td> <td> density(num/km^2*1000) </td> <td> magnitude </td> </tr>"""
        for i in range (len(result2)):
            tablewrite += "<tr>"
            for j in range (len(result2[0])):
                tablewrite += "<td>"
                tablewrite += str(result2[i][j])
                tablewrite += "</td>"
            tablewrite += "</tr>"
        tablewrite += " </body> </html> "
        if(len(result1)==0):
            return """
                <html>
                    <head>
                        <meta charset="utf-8">
                        <title>資料庫</title>
                    </head>
                    <body>
                        <p> <!-- 標題 -->
                            <h1><b>Database Final Project</b> <i>- Horrible Earthquake </i><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/1c/USGS_logo_green.svg/1920px-USGS_logo_green.svg.png" alt="圖片無法顯示" title="USGS美國地質調查局"width="100px"height="45px"align="top"></h1>
                        </p>
                        <h4>Team members：黃彥慈、陳睦夫、葉眉湘</h4><hr>
                        <h4> 該州沒有任何地震發生！ </h4><br>
                        <h4> There's no earthquake happened in the state！ </h4>
                    </body>
                </html>
            """
        return tablewrite
    return html_response


if __name__ == "__main__":
#    app.run(debug = True)
#    app.run(host = "127.0.0.1",port = 1234)
    app.run()


